import AdmZip from 'adm-zip';
import fs from 'fs';
import path from 'path';

const zip = new AdmZip();

function addFilesRecursively(dir, zipDir = "") {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    if (file === 'node_modules' || file === '.git' || file === 'dist' || file === 'public' || file === '.npm') {
      continue;
    }
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    const zipPath = zipDir ? path.join(zipDir, file) : file;
    if (stat.isDirectory()) {
      addFilesRecursively(fullPath, zipPath);
    } else {
      zip.addLocalFile(fullPath, zipDir);
    }
  }
}

try {
  fs.mkdirSync('public', { recursive: true });
  addFilesRecursively('.');
  zip.writeZip('public/project_source.zip');
  console.log('Zip file created successfully in public/project_source.zip');
} catch (error) {
  console.error('Error creating zip file:', error);
}
