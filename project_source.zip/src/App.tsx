import React, { useState, useEffect } from 'react';
import { Partner, Team, GivingData, ActivityLog, SessionState, GivingState } from './types';
import {
  INITIAL_TEAMS,
  INITIAL_PARTNERS,
  INITIAL_GIVING_DATA,
  createBlankGivingState,
  formatMonthKey
} from './utils';
import Login from './components/Login';
import Header from './components/Header';
import AdminPanel from './components/AdminPanel';
import TeamDashboard from './components/TeamDashboard';
import GeneralPage from './components/GeneralPage';
import { Globe, Lock, LayoutDashboard, ClipboardList } from 'lucide-react';

// Firebase imports
import { collection, onSnapshot, doc, setDoc, deleteDoc, getDocFromServer } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';

export default function App() {
  // --- STATE INITIALIZATION ---
  
  // Teams list
  const [teams, setTeams] = useState<Team[]>(INITIAL_TEAMS);

  // Partners list
  const [partners, setPartners] = useState<Partner[]>(INITIAL_PARTNERS);

  // Giving records
  const [givingData, setGivingData] = useState<GivingData>(INITIAL_GIVING_DATA);

  // Activity Logs
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

  // Month selector (Defaulting to current month in 2026, e.g. July 2026)
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-07');

  // Session State (Null means logged out)
  const [session, setSession] = useState<SessionState>(() => {
    const saved = localStorage.getItem('partners_session');
    return saved ? JSON.parse(saved) : { role: null, teamId: null };
  });

  // Logged-in navigation tab (allows users to view the 'dashboard' or look at the 'general' portal inside their session)
  const [internalTab, setInternalTab] = useState<'workspace' | 'general'>('workspace');

  // --- FIRESTORE PERSISTENCE & REAL-TIME SYNCHRONIZERS ---

  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    }
    testConnection();
  }, []);

  useEffect(() => {
    localStorage.setItem('partners_session', JSON.stringify(session));
  }, [session]);

  useEffect(() => {
    // 1. Sync Teams
    const unsubTeams = onSnapshot(collection(db, 'teams'), (snapshot) => {
      if (snapshot.empty) {
        // Seed teams
        INITIAL_TEAMS.forEach(async (t) => {
          try {
            await setDoc(doc(db, 'teams', t.id), t);
          } catch (err) {
            handleFirestoreError(err, OperationType.WRITE, `teams/${t.id}`);
          }
        });
      } else {
        const loadedTeams: Team[] = [];
        snapshot.forEach((doc) => {
          loadedTeams.push(doc.data() as Team);
        });
        setTeams(loadedTeams);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'teams');
    });

    // 2. Sync Partners
    const unsubPartners = onSnapshot(collection(db, 'partners'), (snapshot) => {
      if (snapshot.empty) {
        // Seed partners
        INITIAL_PARTNERS.forEach(async (p) => {
          try {
            await setDoc(doc(db, 'partners', p.id), p);
          } catch (err) {
            handleFirestoreError(err, OperationType.WRITE, `partners/${p.id}`);
          }
        });
      } else {
        const loadedPartners: Partner[] = [];
        snapshot.forEach((doc) => {
          loadedPartners.push(doc.data() as Partner);
        });
        loadedPartners.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        setPartners(loadedPartners);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'partners');
    });

    // 3. Sync Giving Records
    const unsubGiving = onSnapshot(collection(db, 'giving_records'), (snapshot) => {
      if (snapshot.empty) {
        // Seed giving records
        Object.entries(INITIAL_GIVING_DATA).forEach(async ([partnerId, history]) => {
          try {
            await setDoc(doc(db, 'giving_records', partnerId), history);
          } catch (err) {
            handleFirestoreError(err, OperationType.WRITE, `giving_records/${partnerId}`);
          }
        });
      } else {
        const loadedGiving: GivingData = {};
        snapshot.forEach((doc) => {
          loadedGiving[doc.id] = doc.data() as { [monthKey: string]: GivingState };
        });
        setGivingData(loadedGiving);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'giving_records');
    });

    // 4. Sync Activity Logs
    const unsubLogs = onSnapshot(collection(db, 'activity_logs'), (snapshot) => {
      const loadedLogs: ActivityLog[] = [];
      snapshot.forEach((doc) => {
        loadedLogs.push(doc.data() as ActivityLog);
      });
      loadedLogs.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
      setActivityLogs(loadedLogs);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'activity_logs');
    });

    return () => {
      unsubTeams();
      unsubPartners();
      unsubGiving();
      unsubLogs();
    };
  }, []);

  // --- LOGGING HELPER ---
  const addLog = async (actor: string, action: string) => {
    const logId = `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const newLog: ActivityLog = {
      id: logId,
      timestamp: new Date().toISOString(),
      actor,
      action
    };
    try {
      await setDoc(doc(db, 'activity_logs', logId), newLog);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `activity_logs/${logId}`);
    }
  };

  // --- ACTIONS & OPERATIONS ---

  // 1. Session management
  const handleLoginSuccess = (role: 'admin' | 'team', teamId: string | null) => {
    setSession({ role, teamId });
    setInternalTab('workspace');
    
    let actorName = 'Admin';
    if (role === 'team' && teamId) {
      const team = teams.find(t => t.id === teamId);
      actorName = team ? team.name : 'Team User';
    }
    
    addLog(actorName, `Signed into tracking system workspace.`);
  };

  const handleLogout = () => {
    let actorName = 'User';
    if (session.role === 'admin') {
      actorName = 'Admin';
    } else if (session.role === 'team' && session.teamId) {
      const team = teams.find(t => t.id === session.teamId);
      actorName = team ? team.name : 'Team User';
    }
    
    addLog(actorName, `Logged out of system workspace.`);
    setSession({ role: null, teamId: null });
    setInternalTab('workspace');
  };

  // 2. Add new partners in bulk
  const handleAddPartners = async (newNames: string[], targetTeamId: string | null) => {
    let destName = 'General List';
    if (targetTeamId) {
      const team = teams.find(t => t.id === targetTeamId);
      destName = team ? team.name : 'Team';
    }

    const newPartners: Partner[] = newNames.map((name, i) => ({
      id: `p-${Date.now()}-${i}-${Math.random().toString(36).substr(2, 3)}`,
      name,
      teamId: targetTeamId,
      createdAt: new Date().toISOString()
    }));

    for (const p of newPartners) {
      try {
        await setDoc(doc(db, 'partners', p.id), p);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `partners/${p.id}`);
      }
    }

    // Track actor taking this action
    let actor = 'Public Visitor';
    if (session.role === 'admin') actor = 'Admin';
    else if (session.role === 'team' && session.teamId) {
      const team = teams.find(t => t.id === session.teamId);
      actor = team ? team.name : 'Team User';
    }

    addLog(actor, `Bulk uploaded ${newNames.length} new partner(s) to ${destName}.`);
  };

  // 3. Update giving state checkboxes
  const handleToggleGiving = async (
    partnerId: string,
    monthKey: string,
    type: 'week' | 'monthly' | 'annual',
    weekIndex?: number
  ) => {
    const partnerRecord = givingData[partnerId] || {};
    const currentRecord = partnerRecord[monthKey] || createBlankGivingState();
    
    const updatedRecord = { ...currentRecord };

    if (type === 'week' && typeof weekIndex === 'number') {
      const updatedWeeks = [...updatedRecord.weeks];
      updatedWeeks[weekIndex] = !updatedWeeks[weekIndex];
      updatedRecord.weeks = updatedWeeks;
    } else if (type === 'monthly') {
      updatedRecord.monthly = !updatedRecord.monthly;
    } else if (type === 'annual') {
      updatedRecord.annual = !updatedRecord.annual;
    }

    try {
      await setDoc(doc(db, 'giving_records', partnerId), {
        [monthKey]: updatedRecord
      }, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `giving_records/${partnerId}`);
    }

    // Logging trigger details
    let actor = 'Admin';
    if (session.role === 'team' && session.teamId) {
      const team = teams.find(t => t.id === session.teamId);
      actor = team ? team.name : 'Team User';
    }

    const partner = partners.find(p => p.id === partnerId);
    const pName = partner ? partner.name : 'Partner';
    const readableMonth = formatMonthKey(monthKey);

    let details = '';
    if (type === 'week') details = `Week ${weekIndex! + 1} Status`;
    else if (type === 'monthly') details = 'Monthly Goal Checklist';
    else if (type === 'annual') details = 'Annual Contribution Checklist';

    addLog(actor, `Toggled ${details} for partner ${pName} (${readableMonth}).`);
  };

  // 4. Assign partners to a team
  const handleAssignPartner = async (partnerId: string, teamId: string | null) => {
    const partner = partners.find(p => p.id === partnerId);
    if (!partner) return;

    try {
      await setDoc(doc(db, 'partners', partnerId), {
        ...partner,
        teamId
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `partners/${partnerId}`);
    }

    let actor = 'Admin';
    if (session.role === 'team' && session.teamId) {
      const team = teams.find(t => t.id === session.teamId);
      actor = team ? team.name : 'Team User';
    }

    const pName = partner.name;

    let destName = 'General Unassigned Category';
    if (teamId) {
      const team = teams.find(t => t.id === teamId);
      destName = team ? team.name : 'Team';
    }

    addLog(actor, `Reallocated ${pName} to ${destName}.`);
  };

  // 5. Update team profile settings (Admin only)
  const handleUpdateTeams = async (updatedTeams: Team[]) => {
    for (const t of updatedTeams) {
      try {
        await setDoc(doc(db, 'teams', t.id), t);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `teams/${t.id}`);
      }
    }
    addLog('Admin', `Updated team profile names and/or credentials.`);
  };

  // 6. Clear system history logs
  const handleClearLogs = async () => {
    for (const log of activityLogs) {
      try {
        await deleteDoc(doc(db, 'activity_logs', log.id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `activity_logs/${log.id}`);
      }
    }
    addLog('Admin', `Cleared action history trail.`);
  };

  // Current session team name (if team logged in)
  const activeTeamName = session.role === 'team' && session.teamId
    ? (teams.find(t => t.id === session.teamId)?.name || 'Team Workspace')
    : null;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased text-slate-900 selection:bg-emerald-500/20">
      
      {/* --- LOGGED-IN VIEW --- */}
      {session.role !== null ? (
        <>
          <Header
            currentRole={session.role}
            activeTeamName={activeTeamName}
            selectedMonth={selectedMonth}
            onMonthChange={setSelectedMonth}
            onLogout={handleLogout}
          />

          {/* Inline Navigation for Session Users */}
          <div className="bg-white border-b border-slate-200 print:hidden">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex gap-4">
                <button
                  id="nav-workspace-btn"
                  onClick={() => setInternalTab('workspace')}
                  className={`py-3.5 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
                    internalTab === 'workspace'
                      ? 'border-slate-950 text-slate-950 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  Your Workspace Dashboard
                </button>
                <button
                  id="nav-general-btn"
                  onClick={() => setInternalTab('general')}
                  className={`py-3.5 text-xs font-semibold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
                    internalTab === 'general'
                      ? 'border-slate-950 text-slate-950 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Globe className="w-4 h-4" />
                  General Unassigned Partners
                </button>
              </div>
            </div>
          </div>

          <main id="main-content" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {internalTab === 'workspace' ? (
              session.role === 'admin' ? (
                <AdminPanel
                  partners={partners}
                  teams={teams}
                  givingData={givingData}
                  activityLogs={activityLogs}
                  selectedMonth={selectedMonth}
                  onUpdateTeams={handleUpdateTeams}
                  onAddPartners={handleAddPartners}
                  onAssignPartner={handleAssignPartner}
                  onToggleGiving={handleToggleGiving}
                  onClearLogs={handleClearLogs}
                />
              ) : (
                <TeamDashboard
                  activeTeamId={session.teamId!}
                  partners={partners}
                  teams={teams}
                  givingData={givingData}
                  selectedMonth={selectedMonth}
                  onAddPartners={handleAddPartners}
                  onToggleGiving={handleToggleGiving}
                  onAssignPartner={handleAssignPartner}
                />
              )
            ) : (
              <GeneralPage
                partners={partners}
                teams={teams}
                givingData={givingData}
                onAddPartners={handleAddPartners}
                onAssignPartner={handleAssignPartner}
                onGoToLogin={() => setInternalTab('workspace')}
              />
            )}
          </main>
        </>
      ) : (
        /* --- PUBLIC / LOGGED-OUT VIEW --- */
        <div className="flex-1 flex flex-col">
          {/* Top navigation header */}
          <header className="bg-white border-b border-slate-200 py-4 shadow-xs">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 bg-slate-950 rounded-lg flex items-center justify-center font-bold text-white text-sm">P</span>
                <span className="text-sm font-bold text-slate-900 tracking-tight font-sans">
                  Partners Tracker
                </span>
              </div>
            </div>
          </header>

          <main className="flex-1">
            <Login teams={teams} onLoginSuccess={handleLoginSuccess} />
          </main>
        </div>
      )}

      {/* Modern Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-[11px] text-slate-400 font-mono select-none mt-auto print:hidden">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p>© 2026 Partners Tracker. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
