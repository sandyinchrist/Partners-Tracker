import { Partner, Team, GivingData, GivingState } from './types';

// Helper to clean and split names from text area (by newline, comma, or semicolon)
export function parsePartnerNames(rawText: string): string[] {
  if (!rawText || !rawText.trim()) return [];
  
  // Split on newlines first, then split on commas or semicolons
  const rawLines = rawText.split(/[\n,;]+/);
  
  return rawLines
    .map(name => name.trim())
    .filter(name => name.length > 0);
}

// Format a month key into a readable label (e.g. "2026-07" -> "July 2026")
export function formatMonthKey(monthKey: string): string {
  const [year, month] = monthKey.split('-');
  const date = new Date(parseInt(year), parseInt(month) - 1, 1);
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

// Initial default teams
export const INITIAL_TEAMS: Team[] = [
  { id: 'team-1', name: 'Alpha Ministers', password: 'team1' },
  { id: 'team-2', name: 'Grace Partners', password: 'team2' },
  { id: 'team-3', name: 'Faith Builders', password: 'team3' },
  { id: 'team-4', name: 'Hope Sowers', password: 'team4' },
  { id: 'team-5', name: 'Love Pillars', password: 'team5' },
  { id: 'team-6', name: 'Mercy Stewards', password: 'team6' },
];

// Initial default partners for immediate utility
export const INITIAL_PARTNERS: Partner[] = [
  { id: 'p-1', name: 'Pastor David Vance', teamId: 'team-1', createdAt: '2026-07-01T12:00:00Z' },
  { id: 'p-2', name: 'Minister Sarah Jenkins', teamId: 'team-1', createdAt: '2026-07-01T12:15:00Z' },
  { id: 'p-3', name: 'Brother Andrew Miller', teamId: 'team-2', createdAt: '2026-07-01T12:20:00Z' },
  { id: 'p-4', name: 'Sister Helen Clark', teamId: 'team-2', createdAt: '2026-07-01T12:30:00Z' },
  { id: 'p-5', name: 'Deacon Joshua Sterling', teamId: 'team-3', createdAt: '2026-07-02T09:00:00Z' },
  { id: 'p-6', name: 'Evangelist Deborah Croft', teamId: 'team-4', createdAt: '2026-07-02T09:45:00Z' },
  { id: 'p-7', name: 'Dr. Michael Peterson', teamId: 'team-5', createdAt: '2026-07-02T10:10:00Z' },
  { id: 'p-8', name: 'Sister Rachel Adams', teamId: 'team-6', createdAt: '2026-07-02T10:30:00Z' },
  { id: 'p-9', name: 'Elder Thomas Wright', teamId: null, createdAt: '2026-07-03T14:00:00Z' },
  { id: 'p-10', name: 'Minister Naomi Vance', teamId: null, createdAt: '2026-07-03T14:10:00Z' },
];

// Create a blank giving state
export function createBlankGivingState(): GivingState {
  return {
    weeks: [false, false, false, false, false],
    monthly: false,
    annual: false,
  };
}

// Initial mock giving data to populate tables
export const INITIAL_GIVING_DATA: GivingData = {
  'p-1': {
    '2026-07': { weeks: [true, true, false, false, false], monthly: true, annual: false }
  },
  'p-2': {
    '2026-07': { weeks: [true, true, true, false, false], monthly: true, annual: true }
  },
  'p-3': {
    '2026-07': { weeks: [false, false, false, false, false], monthly: false, annual: false }
  },
  'p-4': {
    '2026-07': { weeks: [true, false, false, false, false], monthly: false, annual: false }
  },
  'p-5': {
    '2026-07': { weeks: [true, true, true, true, false], monthly: true, annual: false }
  }
};

// Export to CSV helper
export function exportToCSV(
  partners: Partner[],
  teams: Team[],
  givingData: GivingData,
  monthKey: string
) {
  const monthName = formatMonthKey(monthKey);
  const teamMap = new Map(teams.map(t => [t.id, t.name]));
  
  const headers = [
    'Partner ID',
    'Partner Name',
    'Assigned Team',
    'Week 1',
    'Week 2',
    'Week 3',
    'Week 4',
    'Week 5',
    'Monthly Status',
    'Annual Status'
  ];
  
  const rows = partners.map(partner => {
    const teamName = partner.teamId ? (teamMap.get(partner.teamId) || 'Unknown') : 'Unassigned (General)';
    const gState = givingData[partner.id]?.[monthKey] || createBlankGivingState();
    
    return [
      partner.id,
      `"${partner.name.replace(/"/g, '""')}"`,
      `"${teamName}"`,
      gState.weeks[0] ? 'Gave' : 'Not Given',
      gState.weeks[1] ? 'Gave' : 'Not Given',
      gState.weeks[2] ? 'Gave' : 'Not Given',
      gState.weeks[3] ? 'Gave' : 'Not Given',
      gState.weeks[4] ? 'Gave' : 'Not Given',
      gState.monthly ? 'Completed' : 'Pending',
      gState.annual ? 'Completed' : 'Pending'
    ];
  });
  
  const csvContent = [
    `"Partners Giving Report for ${monthName}"`,
    '',
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\r\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Partners_Giving_Report_${monthKey}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Print trigger helper
export function triggerPrint() {
  window.print();
}
