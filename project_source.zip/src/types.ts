export interface Partner {
  id: string;
  name: string;
  teamId: string | null; // null represents general / unassigned partners
  createdAt: string;
}

export interface GivingState {
  weeks: boolean[]; // Array of size 5 representing Week 1 to Week 5
  monthly: boolean; // Monthly target met
  annual: boolean;  // Annual target met
}

// Maps month key (e.g. "2026-07") to the giving state for that partner
export interface GivingData {
  [partnerId: string]: {
    [monthKey: string]: GivingState;
  };
}

export interface Team {
  id: string; // 'team-1', 'team-2', etc.
  name: string;
  password: string;
}

export interface ActivityLog {
  id: string;
  timestamp: string; // ISO string
  actor: string;     // Name of team or Admin
  action: string;    // Description of action
}

export interface SessionState {
  role: 'admin' | 'team' | null;
  teamId: string | null; // null if admin or logged out
}
