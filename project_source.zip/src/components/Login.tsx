import React, { useState } from 'react';
import { Team } from '../types';
import { Shield, Users, Lock, LogIn, AlertCircle } from 'lucide-react';

interface LoginProps {
  teams: Team[];
  onLoginSuccess: (role: 'admin' | 'team', teamId: string | null) => void;
}

export default function Login({ teams, onLoginSuccess }: LoginProps) {
  const [selectedRole, setSelectedRole] = useState<'admin' | 'team'>('team');
  const [selectedTeamId, setSelectedTeamId] = useState<string>('team-1');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (selectedRole === 'admin') {
      // Local check or custom password from state/storage
      const storedAdminPass = localStorage.getItem('admin_password') || 'admin';
      if (password === storedAdminPass) {
        onLoginSuccess('admin', null);
      } else {
        setError('Invalid Admin password.');
      }
    } else {
      const team = teams.find(t => t.id === selectedTeamId);
      if (team) {
        if (password === team.password) {
          onLoginSuccess('team', team.id);
        } else {
          setError(`Invalid password for ${team.name}.`);
        }
      } else {
        setError('Selected team not found.');
      }
    }
  };

  return (
    <div id="login-container" className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md bg-white border border-slate-100 rounded-2xl shadow-xl overflow-hidden">
        {/* Top brand header */}
        <div className="bg-slate-900 px-6 py-8 text-white text-center relative">
          <div className="mx-auto w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20 mb-3">
            <Users className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-xl font-bold font-sans tracking-tight">Partners Tracker</h2>
          <p className="text-xs text-slate-400 mt-1 font-mono">Select your workspace role to begin tracking</p>
          
          {/* Subtle decoration */}
          <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-xl translate-x-8 -translate-y-8 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl -translate-x-8 translate-y-8 pointer-events-none" />
        </div>

        {/* Form content */}
        <form onSubmit={handleLogin} className="p-8 space-y-6">
          {/* Role selector tabs */}
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button
              id="role-team-btn"
              type="button"
              onClick={() => {
                setSelectedRole('team');
                setError('');
                setPassword('');
              }}
              className={`flex-1 py-2.5 text-xs font-medium rounded-lg transition-all flex items-center justify-center gap-2 ${
                selectedRole === 'team'
                  ? 'bg-white text-slate-950 shadow-sm font-semibold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Users className="w-4 h-4" />
              Team Member
            </button>
            <button
              id="role-admin-btn"
              type="button"
              onClick={() => {
                setSelectedRole('admin');
                setError('');
                setPassword('');
              }}
              className={`flex-1 py-2.5 text-xs font-medium rounded-lg transition-all flex items-center justify-center gap-2 ${
                selectedRole === 'admin'
                  ? 'bg-white text-slate-950 shadow-sm font-semibold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Shield className="w-4 h-4" />
              System Admin
            </button>
          </div>

          <div className="space-y-4">
            {/* Team selection (only if team role selected) */}
            {selectedRole === 'team' && (
              <div className="space-y-1.5">
                <label htmlFor="team-select" className="block text-xs font-medium text-slate-700">
                  Select Your Team
                </label>
                <div className="relative">
                  <select
                    id="team-select"
                    value={selectedTeamId}
                    onChange={(e) => {
                      setSelectedTeamId(e.target.value);
                      setError('');
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all appearance-none cursor-pointer font-sans"
                  >
                    {teams.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-slate-500">
                    <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                      <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                  </div>
                </div>
              </div>
            )}

            {/* Password input */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label htmlFor="password-input" className="block text-xs font-medium text-slate-700">
                  Password
                </label>
                <span className="text-[10px] font-mono text-slate-400">
                  {selectedRole === 'admin' ? 'Default: admin' : 'Default: team1, team2, etc.'}
                </span>
              </div>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </span>
                <input
                  id="password-input"
                  type="password"
                  required
                  placeholder="Enter access password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-sans"
                />
              </div>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div id="login-error" className="flex items-start gap-2.5 p-3.5 bg-rose-50 text-rose-700 rounded-xl border border-rose-100 text-xs font-sans">
              <AlertCircle className="w-4.5 h-4.5 shrink-0 mt-0.5 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          {/* Submit button */}
          <button
            id="login-submit-btn"
            type="submit"
            className="w-full bg-slate-950 hover:bg-slate-900 active:scale-[0.98] text-white py-3 px-4 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-slate-950/10"
          >
            <LogIn className="w-4 h-4" />
            Sign In to Dashboard
          </button>
        </form>
      </div>
    </div>
  );
}
