import React, { useState } from 'react';
import { Partner, Team, GivingData, ActivityLog } from '../types';
import {
  TrendingUp,
  Settings,
  UserPlus,
  ClipboardList,
  Search,
  Filter,
  UserCheck,
  UserX,
  Plus,
  ArrowRight,
  Download,
  Printer,
  CheckCircle,
  HelpCircle,
  X,
  FileText,
  Upload
} from 'lucide-react';
import { parsePartnerNames, createBlankGivingState, exportToCSV, triggerPrint, formatMonthKey } from '../utils';

interface AdminPanelProps {
  partners: Partner[];
  teams: Team[];
  givingData: GivingData;
  activityLogs: ActivityLog[];
  selectedMonth: string;
  onUpdateTeams: (updatedTeams: Team[]) => void;
  onAddPartners: (newNames: string[], teamId: string | null) => void;
  onAssignPartner: (partnerId: string, teamId: string | null) => void;
  onToggleGiving: (partnerId: string, monthKey: string, type: 'week' | 'monthly' | 'annual', weekIndex?: number) => void;
  onClearLogs: () => void;
}

export default function AdminPanel({
  partners,
  teams,
  givingData,
  activityLogs,
  selectedMonth,
  onUpdateTeams,
  onAddPartners,
  onAssignPartner,
  onToggleGiving,
  onClearLogs
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'reports' | 'partners' | 'upload' | 'teams' | 'logs'>('reports');

  // Search & Filters for Partner Registry
  const [searchQuery, setSearchQuery] = useState('');
  const [teamFilter, setTeamFilter] = useState<string>('all');
  const [givingFilter, setGivingFilter] = useState<'all' | 'given' | 'not-given' | 'not-given-year'>('all');

  // State for Bulk upload text area and destination
  const [bulkInput, setBulkInput] = useState('');
  const [uploadDest, setUploadDest] = useState<string>('general'); // 'general' or specific teamId
  const [uploadSuccessMsg, setUploadSuccessMsg] = useState('');

  // Drag and Drop upload states
  const [isDragging, setIsDragging] = useState(false);
  const [fileError, setFileError] = useState('');
  const [fileSuccess, setFileSuccess] = useState('');

  const handleFileProcess = (file: File) => {
    setFileError('');
    setFileSuccess('');
    
    const fileType = file.name.split('.').pop()?.toLowerCase();
    if (fileType !== 'txt' && fileType !== 'csv') {
      setFileError('Unsupported file type. Please upload a .txt or .csv file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (!text) {
        setFileError('Could not read file content or file is empty.');
        return;
      }

      const lines = text.split(/\r?\n/);
      const parsedNames: string[] = [];

      lines.forEach((line, index) => {
        const trimmed = line.trim();
        if (!trimmed) return;

        if (trimmed.includes(',')) {
          const parts = trimmed.split(',').map(p => p.trim()).filter(p => p.length > 0);
          
          const containsHeaderWord = parts.some(p => {
            const lp = p.toLowerCase();
            return lp === 'name' || lp === 'partner' || lp === 'partner name' || lp === 'email' || lp === 'id' || lp === 'team';
          });
          if (index === 0 && containsHeaderWord) {
            return;
          }

          if (parts.length > 0) {
            const isEmail = (str: string) => str.includes('@');
            const isNumber = (str: string) => !isNaN(Number(str));
            
            if (parts.length === 2 && !isEmail(parts[0]) && !isEmail(parts[1]) && !isNumber(parts[0]) && !isNumber(parts[1])) {
              const namePart = parts.find(p => !isEmail(p) && !isNumber(p));
              if (namePart && namePart.length > 1) {
                parsedNames.push(namePart);
              }
            } else {
              const firstCol = parts[0];
              if (firstCol && !isEmail(firstCol) && !isNumber(firstCol) && firstCol.length > 1) {
                parsedNames.push(firstCol);
              }
            }
          }
        } else {
          if (trimmed.length > 1) {
            parsedNames.push(trimmed);
          }
        }
      });

      const cleanedNames = parsedNames.filter(name => {
        const l = name.toLowerCase();
        return l !== 'name' && l !== 'partner' && l !== 'partner name' && l !== 'full name' && l !== 'first name' && l !== 'last name';
      });

      if (cleanedNames.length === 0) {
        setFileError('No valid partner names found in the file.');
        return;
      }

      setBulkInput(prev => {
        const prefix = prev.trim() ? prev.trim() + '\n' : '';
        return prefix + cleanedNames.join('\n');
      });

      setFileSuccess(`Successfully parsed ${cleanedNames.length} names from "${file.name}"!`);
      setTimeout(() => setFileSuccess(''), 6000);
    };

    reader.onerror = () => {
      setFileError('An error occurred while reading the file.');
    };

    reader.readAsText(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  // States for Editing Teams
  const [editingTeams, setEditingTeams] = useState<Team[]>([...teams]);
  const [teamSaveSuccess, setTeamSaveSuccess] = useState('');

  // Save modified team configuration
  const handleSaveTeamConfig = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateTeams(editingTeams);
    setTeamSaveSuccess('Team configurations updated successfully.');
    setTimeout(() => setTeamSaveSuccess(''), 4000);
  };

  // Modify individual team fields
  const handleTeamFieldChange = (index: number, field: keyof Team, value: string) => {
    const updated = [...editingTeams];
    updated[index] = { ...updated[index], [field]: value };
    setEditingTeams(updated);
  };

  // Bulk Partner Addition
  const handleBulkAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const names = parsePartnerNames(bulkInput);
    if (names.length === 0) return;

    const targetTeamId = uploadDest === 'general' ? null : uploadDest;
    onAddPartners(names, targetTeamId);
    setBulkInput('');
    setUploadSuccessMsg(`Successfully imported ${names.length} partners.`);
    setTimeout(() => setUploadSuccessMsg(''), 5000);
  };

  // Filter partners list according to query & chosen status
  const filteredPartners = partners.filter(partner => {
    const matchesSearch = partner.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          partner.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTeam = teamFilter === 'all' || 
                        (teamFilter === 'general' && partner.teamId === null) || 
                        partner.teamId === teamFilter;

    if (!matchesSearch || !matchesTeam) return false;

    const state = givingData[partner.id]?.[selectedMonth] || createBlankGivingState();
    const hasGivenAny = state.weeks.some(w => w) || state.monthly || state.annual;

    if (givingFilter === 'given') {
       return hasGivenAny;
    } else if (givingFilter === 'not-given') {
       // "Who haven't given in selected month" -> did not pay any week, monthly, or annual
       return !hasGivenAny;
    } else if (givingFilter === 'not-given-year') {
       // "Who haven't given in the whole year"
       const targetYear = selectedMonth.split('-')[0];
       const partnerHistory = givingData[partner.id] || {};
       const hasGivenInYear = Object.entries(partnerHistory).some(([monthKey, monthState]) => {
         if (!monthKey.startsWith(`${targetYear}-`)) return false;
         return monthState.weeks.some(w => w) || monthState.monthly || monthState.annual;
       });
       return !hasGivenInYear;
    }
    return true;
  });

  // Calculate Consolidated Report Summary metrics
  // For each team, we need Week 1-5 count, Monthly count, Annual count
  const reportByTeam = teams.map(team => {
    const teamPartners = partners.filter(p => p.teamId === team.id);
    const totals = {
      week1: 0,
      week2: 0,
      week3: 0,
      week4: 0,
      week5: 0,
      monthly: 0,
      annual: 0,
      totalCount: teamPartners.length
    };

    teamPartners.forEach(p => {
      const state = givingData[p.id]?.[selectedMonth] || createBlankGivingState();
      if (state.weeks[0]) totals.week1++;
      if (state.weeks[1]) totals.week2++;
      if (state.weeks[2]) totals.week3++;
      if (state.weeks[3]) totals.week4++;
      if (state.weeks[4]) totals.week5++;
      if (state.monthly) totals.monthly++;
      if (state.annual) totals.annual++;
    });

    return {
      teamId: team.id,
      name: team.name,
      ...totals
    };
  });

  // Consolidated general/unassigned partners metrics
  const generalPartners = partners.filter(p => p.teamId === null);
  const generalTotals = {
    week1: 0,
    week2: 0,
    week3: 0,
    week4: 0,
    week5: 0,
    monthly: 0,
    annual: 0,
    totalCount: generalPartners.length
  };
  generalPartners.forEach(p => {
    const state = givingData[p.id]?.[selectedMonth] || createBlankGivingState();
    if (state.weeks[0]) generalTotals.week1++;
    if (state.weeks[1]) generalTotals.week2++;
    if (state.weeks[2]) generalTotals.week3++;
    if (state.weeks[3]) generalTotals.week4++;
    if (state.weeks[4]) generalTotals.week5++;
    if (state.monthly) generalTotals.monthly++;
    if (state.annual) generalTotals.annual++;
  });

  // Calculate cumulative totals across all categories (all teams + general)
  const cumulative = {
    week1: reportByTeam.reduce((sum, item) => sum + item.week1, 0) + generalTotals.week1,
    week2: reportByTeam.reduce((sum, item) => sum + item.week2, 0) + generalTotals.week2,
    week3: reportByTeam.reduce((sum, item) => sum + item.week3, 0) + generalTotals.week3,
    week4: reportByTeam.reduce((sum, item) => sum + item.week4, 0) + generalTotals.week4,
    week5: reportByTeam.reduce((sum, item) => sum + item.week5, 0) + generalTotals.week5,
    monthly: reportByTeam.reduce((sum, item) => sum + item.monthly, 0) + generalTotals.monthly,
    annual: reportByTeam.reduce((sum, item) => sum + item.annual, 0) + generalTotals.annual,
    totalCount: partners.length
  };

  return (
    <div id="admin-panel-root" className="space-y-6">
      {/* Quick Dashboard Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 text-white rounded-2xl p-6 shadow-md relative overflow-hidden print:hidden">
        <div className="space-y-1 z-10">
          <h2 className="text-xl font-bold font-sans tracking-tight">System Administrator Panel</h2>
          <p className="text-xs text-slate-300 font-sans">
            Overseeing <span className="text-emerald-400 font-semibold">{partners.length} partners</span> mapped across <span className="text-emerald-400 font-semibold">{teams.length} distinct teams</span>
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 z-10">
          <button
            id="admin-export-btn"
            onClick={() => exportToCSV(partners, teams, givingData, selectedMonth)}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white px-3.5 py-2 rounded-xl text-xs font-medium transition-all border border-slate-700 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
          <button
            id="admin-print-btn"
            onClick={triggerPrint}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-xl text-xs font-medium transition-all shadow-xs cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Report
          </button>
        </div>

        {/* Decorative backdrop */}
        <div className="absolute top-0 right-1/4 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-8 -right-8 w-40 h-40 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Tab Navigation Menu */}
      <div className="flex border-b border-slate-200 overflow-x-auto gap-1 scrollbar-none bg-slate-50 p-1 rounded-xl print:hidden">
        <button
          id="tab-reports-btn"
          onClick={() => setActiveTab('reports')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'reports'
              ? 'bg-white text-slate-950 shadow-sm font-semibold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          Consolidated Reports
        </button>
        <button
          id="tab-partners-btn"
          onClick={() => setActiveTab('partners')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'partners'
              ? 'bg-white text-slate-950 shadow-sm font-semibold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          Partners Registry
        </button>
        <button
          id="tab-upload-btn"
          onClick={() => setActiveTab('upload')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'upload'
              ? 'bg-white text-slate-950 shadow-sm font-semibold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          Upload & Paste
        </button>
        <button
          id="tab-teams-btn"
          onClick={() => setActiveTab('teams')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'teams'
              ? 'bg-white text-slate-950 shadow-sm font-semibold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Settings className="w-4 h-4" />
          Team Logins / Passwords
        </button>
        <button
          id="tab-logs-btn"
          onClick={() => setActiveTab('logs')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'logs'
              ? 'bg-white text-slate-950 shadow-sm font-semibold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          Activity Logs
        </button>
      </div>

      {/* --- TAB 1: CONSOLIDATED REPORTS --- */}
      {activeTab === 'reports' && (
        <div id="reports-tab-content" className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 font-sans">
                  Consolidated Report Summary: {formatMonthKey(selectedMonth)}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Participation index demonstrating total unique partner contributions.
                </p>
              </div>
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider bg-slate-50 px-2 py-1 rounded-md border border-slate-100">
                Summary
              </span>
            </div>

            {/* Main Report Summary Table */}
            <div className="overflow-x-auto border border-slate-150 rounded-xl">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-250">
                    <th className="px-4 py-3 text-xs font-semibold text-slate-600 font-sans">Team Category</th>
                    <th className="px-3 py-3 text-xs font-semibold text-slate-600 font-sans text-center">Week 1</th>
                    <th className="px-3 py-3 text-xs font-semibold text-slate-600 font-sans text-center">Week 2</th>
                    <th className="px-3 py-3 text-xs font-semibold text-slate-600 font-sans text-center">Week 3</th>
                    <th className="px-3 py-3 text-xs font-semibold text-slate-600 font-sans text-center">Week 4</th>
                    <th className="px-3 py-3 text-xs font-semibold text-slate-600 font-sans text-center">Week 5</th>
                    <th className="px-3 py-3 text-xs font-semibold text-slate-600 font-sans text-center bg-emerald-50/40 text-emerald-800">Monthly</th>
                    <th className="px-3 py-3 text-xs font-semibold text-slate-600 font-sans text-center bg-indigo-50/40 text-indigo-800">Annual</th>
                    <th className="px-4 py-3 text-xs font-semibold text-slate-600 font-sans text-right">Total Partners</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150">
                  {reportByTeam.map((item) => (
                    <tr key={item.teamId} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-4 py-3 text-xs font-semibold text-slate-800 font-sans">
                        {item.name}
                      </td>
                      <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                        {item.week1}
                      </td>
                      <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                        {item.week2}
                      </td>
                      <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                        {item.week3}
                      </td>
                      <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                        {item.week4}
                      </td>
                      <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                        {item.week5}
                      </td>
                      <td className="px-3 py-3 text-xs text-center font-mono bg-emerald-50/20 font-semibold text-emerald-700">
                        {item.monthly}
                      </td>
                      <td className="px-3 py-3 text-xs text-center font-mono bg-indigo-50/20 font-semibold text-indigo-700">
                        {item.annual}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-500 text-right font-mono">
                        {item.totalCount}
                      </td>
                    </tr>
                  ))}

                  {/* General / Unassigned Row */}
                  <tr className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-4 py-3 text-xs font-semibold text-slate-500 italic font-sans">
                      General / Unassigned
                    </td>
                    <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                      {generalTotals.week1}
                    </td>
                    <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                      {generalTotals.week2}
                    </td>
                    <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                      {generalTotals.week3}
                    </td>
                    <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                      {generalTotals.week4}
                    </td>
                    <td className="px-3 py-3 text-xs text-slate-700 text-center font-mono">
                      {generalTotals.week5}
                    </td>
                    <td className="px-3 py-3 text-xs text-center font-mono bg-emerald-50/20 font-semibold text-emerald-700">
                      {generalTotals.monthly}
                    </td>
                    <td className="px-3 py-3 text-xs text-center font-mono bg-indigo-50/20 font-semibold text-indigo-700">
                      {generalTotals.annual}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500 text-right font-mono">
                      {generalTotals.totalCount}
                    </td>
                  </tr>

                  {/* Cumulative Total Row */}
                  <tr className="bg-slate-900 text-white font-semibold">
                    <td className="px-4 py-3.5 text-xs text-white font-sans uppercase tracking-wider">
                      Cumulative Total (All Teams)
                    </td>
                    <td className="px-3 py-3.5 text-xs text-center font-mono text-emerald-400">
                      {cumulative.week1}
                    </td>
                    <td className="px-3 py-3.5 text-xs text-center font-mono text-emerald-400">
                      {cumulative.week2}
                    </td>
                    <td className="px-3 py-3.5 text-xs text-center font-mono text-emerald-400">
                      {cumulative.week3}
                    </td>
                    <td className="px-3 py-3.5 text-xs text-center font-mono text-emerald-400">
                      {cumulative.week4}
                    </td>
                    <td className="px-3 py-3.5 text-xs text-center font-mono text-emerald-400">
                      {cumulative.week5}
                    </td>
                    <td className="px-3 py-3.5 text-xs text-center font-mono bg-emerald-950 text-emerald-300 font-bold border-l border-r border-slate-800">
                      {cumulative.monthly}
                    </td>
                    <td className="px-3 py-3.5 text-xs text-center font-mono bg-indigo-950 text-indigo-300 font-bold">
                      {cumulative.annual}
                    </td>
                    <td className="px-4 py-3.5 text-xs text-right font-mono text-slate-300">
                      {cumulative.totalCount}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex items-center justify-between">
              <div>
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Average Weekly Participation</p>
                <h4 className="text-xl font-bold font-sans text-slate-900 mt-1">
                  {((cumulative.week1 + cumulative.week2 + cumulative.week3 + cumulative.week4 + cumulative.week5) / 5).toFixed(1)}
                </h4>
              </div>
              <div className="w-10 h-10 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-600">
                <CheckCircle className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex items-center justify-between">
              <div>
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Monthly Complete Rate</p>
                <h4 className="text-xl font-bold font-sans text-slate-900 mt-1">
                  {cumulative.totalCount > 0 ? `${Math.round((cumulative.monthly / cumulative.totalCount) * 100)}%` : '0%'}
                </h4>
              </div>
              <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex items-center justify-between">
              <div>
                <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Annual Goal Achieved</p>
                <h4 className="text-xl font-bold font-sans text-slate-900 mt-1">
                  {cumulative.annual} / {cumulative.totalCount}
                </h4>
              </div>
              <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center text-slate-600">
                <UserCheck className="w-5 h-5" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 2: PARTNERS REGISTRY --- */}
      {activeTab === 'partners' && (
        <div id="partners-tab-content" className="space-y-4">
          {/* Filter & Search Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            {/* Search inputs */}
            <div className="flex-1 relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                id="admin-partner-search"
                type="text"
                placeholder="Search partner names or unique IDs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/15 focus:border-emerald-500 transition-all font-sans"
              />
            </div>

            {/* Select filters */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-slate-500 font-medium whitespace-nowrap">Team:</span>
                <select
                  id="admin-team-filter"
                  value={teamFilter}
                  onChange={(e) => setTeamFilter(e.target.value)}
                  className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/10"
                >
                  <option value="all">All Teams</option>
                  <option value="general">Unassigned (General)</option>
                  {teams.map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-xs text-slate-500 font-medium whitespace-nowrap">Giving status:</span>
                <select
                  id="admin-giving-filter"
                  value={givingFilter}
                  onChange={(e) => setGivingFilter(e.target.value as any)}
                  className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/10"
                >
                  <option value="all">All Partners</option>
                  <option value="given">Has given this month (any)</option>
                  <option value="not-given">Who haven't given in selected month</option>
                  <option value="not-given-year">Who haven't given in selected year ({selectedMonth.split('-')[0]})</option>
                </select>
              </div>
            </div>
          </div>

          {/* Quick Filter Buttons / Badges */}
          <div className="flex flex-wrap gap-2 px-1 print:hidden">
            <button
              id="admin-quick-all"
              onClick={() => setGivingFilter('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                givingFilter === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All ({
                partners.filter(p => teamFilter === 'all' || (teamFilter === 'general' && p.teamId === null) || p.teamId === teamFilter).length
              })
            </button>
            <button
              id="admin-quick-given"
              onClick={() => setGivingFilter('given')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                givingFilter === 'given'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
              }`}
            >
              Given This Month ({
                partners.filter(p => {
                  const matchesTeam = teamFilter === 'all' || (teamFilter === 'general' && p.teamId === null) || p.teamId === teamFilter;
                  if (!matchesTeam) return false;
                  const s = givingData[p.id]?.[selectedMonth] || createBlankGivingState();
                  return s.weeks.some(w => w) || s.monthly || s.annual;
                }).length
              })
            </button>
            <button
              id="admin-quick-not-month"
              onClick={() => setGivingFilter('not-given')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                givingFilter === 'not-given'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
              }`}
            >
              Not Given This Month ({
                partners.filter(p => {
                  const matchesTeam = teamFilter === 'all' || (teamFilter === 'general' && p.teamId === null) || p.teamId === teamFilter;
                  if (!matchesTeam) return false;
                  const s = givingData[p.id]?.[selectedMonth] || createBlankGivingState();
                  return !(s.weeks.some(w => w) || s.monthly || s.annual);
                }).length
              })
            </button>
            <button
              id="admin-quick-not-year"
              onClick={() => setGivingFilter('not-given-year')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                givingFilter === 'not-given-year'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
              }`}
            >
              Not Given This Year ({selectedMonth.split('-')[0]}) ({
                partners.filter(p => {
                  const matchesTeam = teamFilter === 'all' || (teamFilter === 'general' && p.teamId === null) || p.teamId === teamFilter;
                  if (!matchesTeam) return false;
                  
                  const targetYear = selectedMonth.split('-')[0];
                  const partnerHistory = givingData[p.id] || {};
                  const hasGivenInYear = Object.entries(partnerHistory).some(([monthKey, monthState]) => {
                    if (!monthKey.startsWith(`${targetYear}-`)) return false;
                    return monthState.weeks.some(w => w) || monthState.monthly || monthState.annual;
                  });
                  return !hasGivenInYear;
                }).length
              })
            </button>
          </div>

          {/* Table list */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-150 flex items-center justify-between bg-slate-50/50">
              <h3 className="text-xs font-bold text-slate-800 font-sans">
                Partners List ({filteredPartners.length} shown)
              </h3>
              <p className="text-[10px] font-mono text-slate-400">
                Check boxes to update giving status, or assign team allocation.
              </p>
            </div>

            <div className="overflow-x-auto">
              {filteredPartners.length === 0 ? (
                <div className="py-12 text-center text-slate-500 space-y-2">
                  <UserX className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="text-xs font-semibold">No partners matched your filters.</p>
                  <p className="text-[10px] text-slate-400">Try adjusting your search query, status filters, or team selector.</p>
                </div>
              ) : (
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/40 border-b border-slate-150 text-[10px] uppercase font-mono tracking-wider text-slate-500">
                      <th className="px-6 py-3 font-semibold">Partner</th>
                      <th className="px-4 py-3 font-semibold">Assigned Team</th>
                      <th className="px-2.5 py-3 font-semibold text-center">W1</th>
                      <th className="px-2.5 py-3 font-semibold text-center">W2</th>
                      <th className="px-2.5 py-3 font-semibold text-center">W3</th>
                      <th className="px-2.5 py-3 font-semibold text-center">W4</th>
                      <th className="px-2.5 py-3 font-semibold text-center">W5</th>
                      <th className="px-3 py-3 font-semibold text-center text-emerald-800">Month</th>
                      <th className="px-3 py-3 font-semibold text-center text-indigo-800">Annual</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {filteredPartners.map(partner => {
                      const gState = givingData[partner.id]?.[selectedMonth] || createBlankGivingState();
                      return (
                        <tr key={partner.id} className="hover:bg-slate-50/40 transition-colors">
                          <td className="px-6 py-3.5">
                            <div className="font-semibold text-slate-850 font-sans">{partner.name}</div>
                            <div className="text-[9px] text-slate-400 font-mono mt-0.5">ID: {partner.id}</div>
                          </td>
                          <td className="px-4 py-3.5">
                            <select
                              id={`assign-team-${partner.id}`}
                              value={partner.teamId || 'unassigned'}
                              onChange={(e) => {
                                const val = e.target.value === 'unassigned' ? null : e.target.value;
                                onAssignPartner(partner.id, val);
                              }}
                              className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                            >
                              <option value="unassigned">Unassigned (General)</option>
                              {teams.map(t => (
                                <option key={t.id} value={t.id}>{t.name}</option>
                              ))}
                            </select>
                          </td>
                          {/* Week 1 */}
                          <td className="px-2.5 py-3.5 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[0]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 0)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Week 2 */}
                          <td className="px-2.5 py-3.5 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[1]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 1)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Week 3 */}
                          <td className="px-2.5 py-3.5 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[2]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 2)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Week 4 */}
                          <td className="px-2.5 py-3.5 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[3]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 3)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Week 5 */}
                          <td className="px-2.5 py-3.5 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[4]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 4)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Monthly */}
                          <td className="px-3 py-3.5 text-center bg-emerald-50/20">
                            <input
                              type="checkbox"
                              checked={gState.monthly}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'monthly')}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Annual */}
                          <td className="px-3 py-3.5 text-center bg-indigo-50/20">
                            <input
                              type="checkbox"
                              checked={gState.annual}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'annual')}
                              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 3: UPLOAD & PASTE --- */}
      {activeTab === 'upload' && (
        <div id="upload-tab-content" className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs max-w-3xl">
          <h3 className="text-sm font-bold text-slate-900 font-sans">
            Add Partners in Bulk
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Easily copy-paste names or enter them manually. This will register new partners and automatically generate IDs.
          </p>

          <form onSubmit={handleBulkAdd} className="mt-5 space-y-5">
            {/* Destination Team */}
            <div className="space-y-1.5">
              <label htmlFor="upload-destination" className="block text-xs font-semibold text-slate-700">
                Choose Destination Team Assignment
              </label>
              <select
                id="upload-destination"
                value={uploadDest}
                onChange={(e) => setUploadDest(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-sans cursor-pointer w-full max-w-md"
              >
                <option value="general">General / Unassigned List (Assign Later)</option>
                {teams.map(t => (
                  <option key={t.id} value={t.id}>Directly to: {t.name}</option>
                ))}
              </select>
            </div>

            {/* File Drag and Drop / Selection Area */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700">
                Upload Partner List File
              </label>
              <div
                id="file-drop-zone"
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => document.getElementById('admin-file-picker')?.click()}
                className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-2 select-none ${
                  isDragging
                    ? 'border-emerald-500 bg-emerald-50/50 scale-[1.01]'
                    : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-300'
                }`}
              >
                <input
                  id="admin-file-picker"
                  type="file"
                  accept=".txt,.csv"
                  className="hidden"
                  onChange={handleFileInputChange}
                />
                <Upload className={`w-8 h-8 ${isDragging ? 'text-emerald-500 animate-bounce' : 'text-slate-400'}`} />
                <p className="text-xs font-semibold text-slate-700">
                  Drag and drop your .txt or .csv list here, or <span className="text-emerald-600 underline">browse computer</span>
                </p>
                <p className="text-[10px] text-slate-400 font-mono">
                  Upload file to extract partner names instantly
                </p>
              </div>

              {/* File feedback messages */}
              {fileError && (
                <p id="admin-file-error" className="text-[11px] text-red-600 font-medium">
                  ⚠️ {fileError}
                </p>
              )}
              {fileSuccess && (
                <p id="admin-file-success" className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse" />
                  {fileSuccess}
                </p>
              )}
            </div>

            {/* Pasted Names input */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label htmlFor="bulk-names-input" className="block text-xs font-semibold text-slate-700">
                  Type or Paste Names of Partners
                </label>
                <span className="text-[10px] text-slate-400 font-mono">
                  Separate by newlines, commas, or semicolons
                </span>
              </div>
              <textarea
                id="bulk-names-input"
                rows={8}
                required
                placeholder="Example:&#10;Pastor Timothy Wright&#10;Sister Abigail Sterling&#10;Brother Matthew Miller"
                value={bulkInput}
                onChange={(e) => setBulkInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs font-mono text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all leading-relaxed"
              />
            </div>

            {/* Success message */}
            {uploadSuccessMsg && (
              <div id="upload-success-toast" className="p-3.5 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-100 text-xs font-medium flex items-center gap-2">
                <CheckCircle className="w-4.5 h-4.5 text-emerald-600" />
                <span>{uploadSuccessMsg}</span>
              </div>
            )}

            {/* Submit button */}
            <button
              id="bulk-submit-btn"
              type="submit"
              className="bg-slate-950 hover:bg-slate-900 active:scale-95 text-white py-2.5 px-5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" />
              Import Partners List
            </button>
          </form>

          {/* Quick instructions / tips */}
          <div className="bg-slate-50 border border-slate-150 rounded-xl p-4 mt-8 space-y-2">
            <h4 className="text-xs font-bold text-slate-800 font-sans flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-slate-500" />
              Quick CSV Upload Tip
            </h4>
            <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
              You can open any Excel or CSV list of partners, copy the column containing partner names, and paste them directly into the input above. Duplicate names will be filtered, and unique tracker identifiers are generated automatically.
            </p>
          </div>
        </div>
      )}

      {/* --- TAB 4: TEAM LOGINS & PASSWORDS --- */}
      {activeTab === 'teams' && (
        <div id="teams-tab-content" className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs max-w-3xl">
          <div className="flex justify-between items-start mb-5">
            <div>
              <h3 className="text-sm font-bold text-slate-900 font-sans">
                Team Settings & Credentials
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Customize the names and secure passwords for each of the 6 monitoring teams.
              </p>
            </div>
            <span className="text-[10px] font-mono text-slate-400 bg-slate-50 border border-slate-100 rounded px-2 py-1">
              Admin Exclusive
            </span>
          </div>

          <form onSubmit={handleSaveTeamConfig} className="space-y-6">
            <div className="space-y-4">
              {editingTeams.map((team, idx) => (
                <div key={team.id} className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center p-4 bg-slate-50 rounded-xl border border-slate-150 hover:border-slate-250 transition-all">
                  {/* Team identifier info */}
                  <div className="sm:col-span-3">
                    <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                      Slot {idx + 1} ({team.id})
                    </span>
                    <p className="text-[11px] font-sans text-slate-500 mt-0.5">Workspace channel</p>
                  </div>

                  {/* Custom Name */}
                  <div className="sm:col-span-5 space-y-1">
                    <label htmlFor={`team-name-${team.id}`} className="block text-[10px] font-semibold text-slate-500 font-sans uppercase">
                      Display Team Name
                    </label>
                    <input
                      id={`team-name-${team.id}`}
                      type="text"
                      required
                      value={team.name}
                      onChange={(e) => handleTeamFieldChange(idx, 'name', e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>

                  {/* Password */}
                  <div className="sm:col-span-4 space-y-1">
                    <label htmlFor={`team-pass-${team.id}`} className="block text-[10px] font-semibold text-slate-500 font-sans uppercase">
                      Access Password
                    </label>
                    <input
                      id={`team-pass-${team.id}`}
                      type="text"
                      required
                      value={team.password}
                      onChange={(e) => handleTeamFieldChange(idx, 'password', e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-800 font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              ))}
            </div>

            {teamSaveSuccess && (
              <div id="team-save-toast" className="p-3.5 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-100 text-xs font-medium flex items-center gap-2">
                <CheckCircle className="w-4.5 h-4.5 text-emerald-600" />
                <span>{teamSaveSuccess}</span>
              </div>
            )}

            <button
              id="save-teams-btn"
              type="submit"
              className="bg-slate-950 hover:bg-slate-900 active:scale-95 text-white py-2.5 px-5 rounded-xl text-xs font-semibold transition-all cursor-pointer shadow-sm flex items-center gap-1.5"
            >
              <Settings className="w-4 h-4" />
              Update Team Configurations
            </button>
          </form>
        </div>
      )}

      {/* --- TAB 5: ACTIVITY LOGS --- */}
      {activeTab === 'logs' && (
        <div id="logs-tab-content" className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs max-w-3xl">
          <div className="flex justify-between items-center mb-5">
            <div>
              <h3 className="text-sm font-bold text-slate-900 font-sans">
                System Activity Log
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Audit trail tracking tracking status updates, member allocations, and configurations.
              </p>
            </div>
            {activityLogs.length > 0 && (
              <button
                id="clear-logs-btn"
                onClick={onClearLogs}
                className="text-xs font-semibold text-rose-600 hover:text-rose-700 hover:underline transition-colors"
              >
                Clear History
              </button>
            )}
          </div>

          <div className="border border-slate-150 rounded-xl overflow-hidden">
            {activityLogs.length === 0 ? (
              <div className="py-12 text-center text-slate-400 space-y-1">
                <ClipboardList className="w-8 h-8 text-slate-300 mx-auto" />
                <p className="text-xs font-semibold">No activity logs recorded yet.</p>
                <p className="text-[10px] text-slate-400">Actions taken across workspace dashboards will reflect here.</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 max-h-[450px] overflow-y-auto">
                {activityLogs.map((log) => (
                  <div key={log.id} className="p-4 flex justify-between items-start gap-3 hover:bg-slate-50/50 transition-colors">
                    <div className="space-y-1">
                      <p className="text-xs text-slate-800 font-medium leading-relaxed font-sans">
                        {log.action}
                      </p>
                      <div className="flex items-center gap-2">
                        <span className="inline-flex px-1.5 py-0.5 rounded text-[9px] font-mono font-semibold bg-slate-100 text-slate-700">
                          {log.actor}
                        </span>
                        <span className="text-[9px] font-mono text-slate-400">
                          {new Date(log.timestamp).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
