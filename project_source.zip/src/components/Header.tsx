import React from 'react';
import { Calendar, LogOut, ShieldAlert, Award } from 'lucide-react';

interface HeaderProps {
  currentRole: 'admin' | 'team' | null;
  activeTeamName: string | null;
  selectedMonth: string; // e.g. "2026-07"
  onMonthChange: (month: string) => void;
  onLogout: () => void;
}

export default function Header({
  currentRole,
  activeTeamName,
  selectedMonth,
  onMonthChange,
  onLogout,
}: HeaderProps) {
  // Generate some months around July 2026 for selection
  const months = [
    { value: '2026-01', label: 'January 2026' },
    { value: '2026-02', label: 'February 2026' },
    { value: '2026-03', label: 'March 2026' },
    { value: '2026-04', label: 'April 2026' },
    { value: '2026-05', label: 'May 2026' },
    { value: '2026-06', label: 'June 2026' },
    { value: '2026-07', label: 'July 2026' },
    { value: '2026-08', label: 'August 2026' },
    { value: '2026-09', label: 'September 2026' },
    { value: '2026-10', label: 'October 2026' },
    { value: '2026-11', label: 'November 2026' },
    { value: '2026-12', label: 'December 2026' },
  ];

  return (
    <header id="app-header" className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-xs print:hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row gap-4 justify-between items-center">
        {/* Title & Badge */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-md shadow-emerald-500/10">
            <Award className="w-5.5 h-5.5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 tracking-tight font-sans">
              Partners Tracker
            </h1>
            <div className="flex items-center gap-1.5 mt-0.5">
              {currentRole === 'admin' ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-medium bg-indigo-50 text-indigo-700 border border-indigo-100">
                  <ShieldAlert className="w-3 h-3" />
                  System Admin
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-medium bg-emerald-50 text-emerald-700 border border-emerald-100">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  {activeTeamName || 'Team User'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Global Selectors and Controls */}
        <div className="flex flex-wrap items-center gap-3.5 w-full sm:w-auto justify-end">
          {/* Month Selector */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5">
            <Calendar className="w-4 h-4 text-slate-500" />
            <span className="text-xs font-medium text-slate-500 font-sans select-none">Month:</span>
            <select
              id="global-month-select"
              value={selectedMonth}
              onChange={(e) => onMonthChange(e.target.value)}
              className="bg-transparent text-xs font-semibold text-slate-800 focus:outline-none cursor-pointer pr-1"
            >
              {months.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>

          {/* Logout Action */}
          <button
            id="logout-btn"
            onClick={onLogout}
            className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 hover:text-slate-900 px-3.5 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </div>
    </header>
  );
}
