import React, { useState } from 'react';
import { Partner, Team, GivingData, ActivityLog } from '../types';
import {
  Users,
  Search,
  Filter,
  UserCheck,
  UserX,
  Plus,
  ArrowRight,
  Download,
  Printer,
  CheckCircle,
  HelpCircle,
  TrendingUp,
  Globe,
  Upload
} from 'lucide-react';
import { parsePartnerNames, createBlankGivingState, exportToCSV, triggerPrint, formatMonthKey } from '../utils';

interface TeamDashboardProps {
  activeTeamId: string;
  partners: Partner[];
  teams: Team[];
  givingData: GivingData;
  selectedMonth: string;
  onAddPartners: (newNames: string[], teamId: string | null) => void;
  onToggleGiving: (partnerId: string, monthKey: string, type: 'week' | 'monthly' | 'annual', weekIndex?: number) => void;
  onAssignPartner: (partnerId: string, teamId: string | null) => void;
}

export default function TeamDashboard({
  activeTeamId,
  partners,
  teams,
  givingData,
  selectedMonth,
  onAddPartners,
  onToggleGiving,
  onAssignPartner
}: TeamDashboardProps) {
  const currentTeam = teams.find(t => t.id === activeTeamId);
  const teamName = currentTeam ? currentTeam.name : 'Active Team';

  // Search parameters
  const [localSearchQuery, setLocalSearchQuery] = useState('');
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  
  // Tab within dashboard
  const [activeTab, setActiveTab] = useState<'track' | 'add' | 'global'>('track');
  
  // Giving Filter
  const [givingFilter, setGivingFilter] = useState<'all' | 'not-given' | 'not-given-year'>('all');

  // Input for adding partners
  const [bulkInput, setBulkInput] = useState('');
  const [uploadSuccessMsg, setUploadSuccessMsg] = useState('');

  // Drag and Drop upload states
  const [isDragging, setIsDragging] = useState(false);
  const [fileError, setFileError] = useState('');
  const [fileSuccess, setFileSuccess] = useState('');

  const handleFileProcess = (file: File) => {
    setFileError('');
    setFileSuccess('');
    
    const fileType = file.name.split('.').pop()?.toLowerCase();
    if (fileType !== 'txt' && fileType !== 'csv') {
      setFileError('Unsupported file type. Please upload a .txt or .csv file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (!text) {
        setFileError('Could not read file content or file is empty.');
        return;
      }

      const lines = text.split(/\r?\n/);
      const parsedNames: string[] = [];

      lines.forEach((line, index) => {
        const trimmed = line.trim();
        if (!trimmed) return;

        if (trimmed.includes(',')) {
          const parts = trimmed.split(',').map(p => p.trim()).filter(p => p.length > 0);
          
          const containsHeaderWord = parts.some(p => {
            const lp = p.toLowerCase();
            return lp === 'name' || lp === 'partner' || lp === 'partner name' || lp === 'email' || lp === 'id' || lp === 'team';
          });
          if (index === 0 && containsHeaderWord) {
            return;
          }

          if (parts.length > 0) {
            const isEmail = (str: string) => str.includes('@');
            const isNumber = (str: string) => !isNaN(Number(str));
            
            if (parts.length === 2 && !isEmail(parts[0]) && !isEmail(parts[1]) && !isNumber(parts[0]) && !isNumber(parts[1])) {
              const namePart = parts.find(p => !isEmail(p) && !isNumber(p));
              if (namePart && namePart.length > 1) {
                parsedNames.push(namePart);
              }
            } else {
              const firstCol = parts[0];
              if (firstCol && !isEmail(firstCol) && !isNumber(firstCol) && firstCol.length > 1) {
                parsedNames.push(firstCol);
              }
            }
          }
        } else {
          if (trimmed.length > 1) {
            parsedNames.push(trimmed);
          }
        }
      });

      const cleanedNames = parsedNames.filter(name => {
        const l = name.toLowerCase();
        return l !== 'name' && l !== 'partner' && l !== 'partner name' && l !== 'full name' && l !== 'first name' && l !== 'last name';
      });

      if (cleanedNames.length === 0) {
        setFileError('No valid partner names found in the file.');
        return;
      }

      setBulkInput(prev => {
        const prefix = prev.trim() ? prev.trim() + '\n' : '';
        return prefix + cleanedNames.join('\n');
      });

      setFileSuccess(`Successfully parsed ${cleanedNames.length} names from "${file.name}"!`);
      setTimeout(() => setFileSuccess(''), 6000);
    };

    reader.onerror = () => {
      setFileError('An error occurred while reading the file.');
    };

    reader.readAsText(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  // 1. Get partners assigned to this team
  const assignedPartners = partners.filter(p => p.teamId === activeTeamId);

  // Filter local partners based on search and giving filter
  const filteredLocalPartners = assignedPartners.filter(partner => {
    const matchesSearch = partner.name.toLowerCase().includes(localSearchQuery.toLowerCase()) ||
                          partner.id.toLowerCase().includes(localSearchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (givingFilter === 'not-given') {
      const state = givingData[partner.id]?.[selectedMonth] || createBlankGivingState();
      // True if the partner hasn't checked any giving status (all weeks, month, and annual are false)
      const hasGivenAny = state.weeks.some(w => w) || state.monthly || state.annual;
      return !hasGivenAny;
    } else if (givingFilter === 'not-given-year') {
      const targetYear = selectedMonth.split('-')[0];
      const partnerHistory = givingData[partner.id] || {};
      const hasGivenInYear = Object.entries(partnerHistory).some(([monthKey, monthState]) => {
        if (!monthKey.startsWith(`${targetYear}-`)) return false;
        return monthState.weeks.some(w => w) || monthState.monthly || monthState.annual;
      });
      return !hasGivenInYear;
    }

    return true;
  });

  // Calculate team-specific summary metrics for report section
  const totalCount = assignedPartners.length;
  const metrics = {
    week1: 0,
    week2: 0,
    week3: 0,
    week4: 0,
    week5: 0,
    monthly: 0,
    annual: 0
  };

  assignedPartners.forEach(p => {
    const state = givingData[p.id]?.[selectedMonth] || createBlankGivingState();
    if (state.weeks[0]) metrics.week1++;
    if (state.weeks[1]) metrics.week2++;
    if (state.weeks[2]) metrics.week3++;
    if (state.weeks[3]) metrics.week4++;
    if (state.weeks[4]) metrics.week5++;
    if (state.monthly) metrics.monthly++;
    if (state.annual) metrics.annual++;
  });

  // Handle local typing/pasting of partners
  const handleLocalAddPartners = (e: React.FormEvent) => {
    e.preventDefault();
    const names = parsePartnerNames(bulkInput);
    if (names.length === 0) return;

    onAddPartners(names, activeTeamId);
    setBulkInput('');
    setUploadSuccessMsg(`Successfully registered ${names.length} partners to ${teamName}.`);
    setTimeout(() => setUploadSuccessMsg(''), 5000);
  };

  // Global search area across other teams & general/unassigned list
  const filteredGlobalPartners = partners.filter(partner => {
    if (!globalSearchQuery || globalSearchQuery.trim().length < 2) return false;
    
    // Search by name or ID
    const matchesSearch = partner.name.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
                          partner.id.toLowerCase().includes(globalSearchQuery.toLowerCase());
    
    return matchesSearch;
  });

  return (
    <div id="team-dashboard-root" className="space-y-6">
      {/* Top Welcome Title Grid */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white border border-slate-200 rounded-2xl p-6 shadow-xs relative overflow-hidden">
        <div className="space-y-1">
          <p className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">Team Workspace</p>
          <h2 className="text-xl font-bold font-sans tracking-tight text-slate-900">{teamName} Dashboard</h2>
          <p className="text-xs text-slate-500 font-sans">
            Tracking giving records for <span className="font-semibold text-emerald-600">{assignedPartners.length} assigned ministers</span>.
          </p>
        </div>
        <div className="flex items-center gap-2 print:hidden">
          <button
            id="team-export-btn"
            onClick={() => exportToCSV(assignedPartners, teams, givingData, selectedMonth)}
            className="flex items-center gap-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shadow-xs"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Export Team List
          </button>
          <button
            id="team-print-btn"
            onClick={triggerPrint}
            className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white px-3.5 py-2 rounded-xl text-xs font-semibold transition-all shadow-xs cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-400" />
            Print Giving Grid
          </button>
        </div>
      </div>

      {/* Team Report Summary Statistics */}
      <div id="team-report-summary" className="bg-slate-900 text-white border border-slate-800 rounded-2xl p-6 shadow-md">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 mb-4">
          <div>
            <h3 className="text-xs font-bold font-mono text-emerald-400 uppercase tracking-widest">
              Participation Report
            </h3>
            <h4 className="text-sm font-semibold text-slate-100 font-sans mt-0.5">
              Stats for selected month: {formatMonthKey(selectedMonth)}
            </h4>
          </div>
          <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-2 py-1 rounded">
            Updated just now
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mt-4">
          {[
            { label: 'Week 1', count: metrics.week1 },
            { label: 'Week 2', count: metrics.week2 },
            { label: 'Week 3', count: metrics.week3 },
            { label: 'Week 4', count: metrics.week4 },
            { label: 'Week 5', count: metrics.week5 },
            { label: 'Monthly Target', count: metrics.monthly, highlight: 'text-emerald-400' },
            { label: 'Annual Target', count: metrics.annual, highlight: 'text-indigo-400' },
          ].map((item, i) => (
            <div key={i} className="bg-slate-950/40 border border-slate-800 p-3.5 rounded-xl text-center space-y-1">
              <p className="text-[10px] font-mono text-slate-400 uppercase tracking-tight">{item.label}</p>
              <div className="flex items-baseline justify-center gap-0.5">
                <span className={`text-base font-bold font-mono ${item.highlight || 'text-white'}`}>
                  {item.count}
                </span>
                <span className="text-[9px] text-slate-500 font-mono">/{totalCount}</span>
              </div>
              <p className="text-[9px] text-slate-500 font-mono font-semibold">
                {totalCount > 0 ? `${Math.round((item.count / totalCount) * 100)}%` : '0%'}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Internal Navigation Subtabs */}
      <div className="flex border-b border-slate-200 overflow-x-auto gap-1 bg-slate-50 p-1 rounded-xl print:hidden">
        <button
          id="team-tab-track"
          onClick={() => setActiveTab('track')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'track'
              ? 'bg-white text-slate-950 shadow-sm'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          Track Team Partners
        </button>
        <button
          id="team-tab-add"
          onClick={() => setActiveTab('add')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'add'
              ? 'bg-white text-slate-950 shadow-sm'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Plus className="w-4 h-4" />
          Paste & Upload Partners
        </button>
        <button
          id="team-tab-global"
          onClick={() => setActiveTab('global')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'global'
              ? 'bg-white text-slate-950 shadow-sm'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Globe className="w-4 h-4" />
          Search Across Teams
        </button>
      </div>

      {/* --- SUBTAB 1: PARTNER TRACKING GRID --- */}
      {activeTab === 'track' && (
        <div id="track-section" className="space-y-4">
          {/* Controls Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row gap-3 justify-between items-center print:hidden">
            {/* Search Box */}
            <div className="relative w-full sm:max-w-xs">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                id="team-partner-search"
                type="text"
                placeholder="Search partner by name..."
                value={localSearchQuery}
                onChange={(e) => setLocalSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-950 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/15 focus:border-emerald-500 transition-all font-sans"
              />
            </div>

            {/* Non-giver filter toggle */}
            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <Filter className="w-4 h-4 text-slate-400 shrink-0" />
              <span className="text-xs text-slate-500 font-medium whitespace-nowrap">Filter Status:</span>
              <select
                id="team-giving-filter"
                value={givingFilter}
                onChange={(e) => setGivingFilter(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 font-sans focus:outline-none focus:ring-2 focus:ring-emerald-500/10"
              >
                <option value="all">Show All Assigned Partners</option>
                <option value="not-given">Who haven't given in {formatMonthKey(selectedMonth)}</option>
                <option value="not-given-year">Who haven't given in selected year ({selectedMonth.split('-')[0]})</option>
              </select>
            </div>
          </div>

          {/* Quick Filter Buttons / Badges */}
          <div className="flex flex-wrap gap-2 px-1 print:hidden">
            <button
              id="team-quick-all"
              onClick={() => setGivingFilter('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                givingFilter === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Team Partners ({assignedPartners.length})
            </button>
            <button
              id="team-quick-not-month"
              onClick={() => setGivingFilter('not-given')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                givingFilter === 'not-given'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
              }`}
            >
              Not Given This Month ({
                assignedPartners.filter(p => {
                  const s = givingData[p.id]?.[selectedMonth] || createBlankGivingState();
                  return !(s.weeks.some(w => w) || s.monthly || s.annual);
                }).length
              })
            </button>
            <button
              id="team-quick-not-year"
              onClick={() => setGivingFilter('not-given-year')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                givingFilter === 'not-given-year'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
              }`}
            >
              Not Given This Year ({selectedMonth.split('-')[0]}) ({
                assignedPartners.filter(p => {
                  const targetYear = selectedMonth.split('-')[0];
                  const partnerHistory = givingData[p.id] || {};
                  const hasGivenInYear = Object.entries(partnerHistory).some(([monthKey, monthState]) => {
                    if (!monthKey.startsWith(`${targetYear}-`)) return false;
                    return monthState.weeks.some(w => w) || monthState.monthly || monthState.annual;
                  });
                  return !hasGivenInYear;
                }).length
              })
            </button>
          </div>

          {/* Core Giving Grid Table */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              {filteredLocalPartners.length === 0 ? (
                <div className="py-16 text-center text-slate-500 space-y-2">
                  <UserX className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="text-xs font-bold text-slate-800">No matching partners found.</p>
                  <p className="text-[10px] text-slate-400">
                    {givingFilter !== 'all' 
                      ? 'Congratulations! All partners may have contributed in this period, or filters are active.' 
                      : 'Try typing a new partner name in the upload tab to register them to your team.'}
                  </p>
                </div>
              ) : (
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                      <th className="px-6 py-3 font-semibold">Minister / Partner Name</th>
                      <th className="px-4 py-3 font-semibold text-center">Week 1</th>
                      <th className="px-4 py-3 font-semibold text-center">Week 2</th>
                      <th className="px-4 py-3 font-semibold text-center">Week 3</th>
                      <th className="px-4 py-3 font-semibold text-center">Week 4</th>
                      <th className="px-4 py-3 font-semibold text-center">Week 5</th>
                      <th className="px-5 py-3 font-semibold text-center text-emerald-800 bg-emerald-50/40">Monthly</th>
                      <th className="px-5 py-3 font-semibold text-center text-indigo-800 bg-indigo-50/40">Annual</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {filteredLocalPartners.map(partner => {
                      const gState = givingData[partner.id]?.[selectedMonth] || createBlankGivingState();
                      return (
                        <tr key={partner.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="font-semibold text-slate-800 font-sans">{partner.name}</div>
                            <div className="text-[9px] text-slate-400 font-mono mt-0.5">ID: {partner.id}</div>
                          </td>
                          {/* Week 1 */}
                          <td className="px-4 py-4 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[0]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 0)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500/20 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Week 2 */}
                          <td className="px-4 py-4 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[1]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 1)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500/20 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Week 3 */}
                          <td className="px-4 py-4 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[2]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 2)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500/20 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Week 4 */}
                          <td className="px-4 py-4 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[3]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 3)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500/20 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Week 5 */}
                          <td className="px-4 py-4 text-center">
                            <input
                              type="checkbox"
                              checked={gState.weeks[4]}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'week', 4)}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500/20 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Monthly Checklist */}
                          <td className="px-5 py-4 text-center bg-emerald-50/10">
                            <input
                              type="checkbox"
                              checked={gState.monthly}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'monthly')}
                              className="w-4.5 h-4.5 rounded text-emerald-600 focus:ring-emerald-500/20 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                          {/* Annual Checklist */}
                          <td className="px-5 py-4 text-center bg-indigo-50/10">
                            <input
                              type="checkbox"
                              checked={gState.annual}
                              onChange={() => onToggleGiving(partner.id, selectedMonth, 'annual')}
                              className="w-4.5 h-4.5 rounded text-indigo-600 focus:ring-indigo-500/20 border-slate-300 cursor-pointer transition-all"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- SUBTAB 2: PASTE & UPLOAD PARTNERS --- */}
      {activeTab === 'add' && (
        <div id="add-section" className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs max-w-3xl">
          <h3 className="text-sm font-bold text-slate-900 font-sans">
            Add Partners to {teamName}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            New partners added here will be automatically assigned to your team workspace.
          </p>

          <form onSubmit={handleLocalAddPartners} className="mt-5 space-y-4">
            {/* File Drag and Drop / Selection Area */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700">
                Upload Partner List File
              </label>
              <div
                id="team-file-drop-zone"
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => document.getElementById('team-file-picker')?.click()}
                className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-2 select-none ${
                  isDragging
                    ? 'border-emerald-500 bg-emerald-50/50 scale-[1.01]'
                    : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-300'
                }`}
              >
                <input
                  id="team-file-picker"
                  type="file"
                  accept=".txt,.csv"
                  className="hidden"
                  onChange={handleFileInputChange}
                />
                <Upload className={`w-8 h-8 ${isDragging ? 'text-emerald-500 animate-bounce' : 'text-slate-400'}`} />
                <p className="text-xs font-semibold text-slate-700">
                  Drag and drop your .txt or .csv list here, or <span className="text-emerald-600 underline">browse computer</span>
                </p>
                <p className="text-[10px] text-slate-400 font-mono">
                  Upload file to extract partner names instantly
                </p>
              </div>

              {/* File feedback messages */}
              {fileError && (
                <p id="team-file-error" className="text-[11px] text-red-600 font-medium">
                  ⚠️ {fileError}
                </p>
              )}
              {fileSuccess && (
                <p id="team-file-success" className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse" />
                  {fileSuccess}
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label htmlFor="team-bulk-names" className="block text-xs font-semibold text-slate-700">
                  Type or Paste Names
                </label>
                <span className="text-[10px] text-slate-400 font-mono">Separate names by newlines or commas</span>
              </div>
              <textarea
                id="team-bulk-names"
                rows={6}
                required
                placeholder="Example:&#10;Brother John Croft&#10;Sister Lydia Peterson"
                value={bulkInput}
                onChange={(e) => setBulkInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs font-mono text-slate-850 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all leading-relaxed"
              />
            </div>

            {uploadSuccessMsg && (
              <div id="team-upload-success" className="p-3 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-100 text-xs font-semibold flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>{uploadSuccessMsg}</span>
              </div>
            )}

            <button
              id="team-bulk-submit-btn"
              type="submit"
              className="bg-slate-950 hover:bg-slate-900 active:scale-95 text-white py-2.5 px-5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" />
              Register Partners to {teamName}
            </button>
          </form>
        </div>
      )}

      {/* --- SUBTAB 3: SEARCH ACROSS TEAMS (GLOBAL) --- */}
      {activeTab === 'global' && (
        <div id="global-search-section" className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 font-sans">
              Search Area: Global Partner Lookup
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Look up partner names across other active teams or the unassigned general directory.
            </p>
          </div>

          {/* Large Search Field */}
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
              <Search className="w-5 h-5" />
            </span>
            <input
              id="team-global-partner-search"
              type="text"
              placeholder="Type at least 2 characters of a partner's name..."
              value={globalSearchQuery}
              onChange={(e) => setGlobalSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-11 pr-4 py-3 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-sans"
            />
          </div>

          {/* Results table */}
          <div>
            {globalSearchQuery.trim().length < 2 ? (
              <div className="py-8 text-center text-slate-400 border border-dashed border-slate-150 rounded-xl">
                <HelpCircle className="w-7 h-7 text-slate-300 mx-auto mb-1" />
                <p className="text-xs">Enter a search query above to look up partners globally.</p>
              </div>
            ) : filteredGlobalPartners.length === 0 ? (
              <div className="py-8 text-center text-slate-500 border border-dashed border-slate-150 rounded-xl">
                <UserX className="w-7 h-7 text-slate-300 mx-auto mb-1" />
                <p className="text-xs font-semibold">No global partners found matching "{globalSearchQuery}"</p>
              </div>
            ) : (
              <div className="border border-slate-150 rounded-xl overflow-hidden mt-3">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 font-mono uppercase text-[10px] text-slate-500 tracking-wider">
                      <th className="px-5 py-3 font-semibold">Partner Name</th>
                      <th className="px-4 py-3 font-semibold">Assigned Team Location</th>
                      <th className="px-4 py-3 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredGlobalPartners.map(partner => {
                      const tInfo = teams.find(t => t.id === partner.teamId);
                      const isMe = partner.teamId === activeTeamId;
                      return (
                        <tr key={partner.id} className="hover:bg-slate-50/30 transition-colors">
                          <td className="px-5 py-3">
                            <div className="font-semibold text-slate-800">{partner.name}</div>
                            <div className="text-[9px] text-slate-400 font-mono">ID: {partner.id}</div>
                          </td>
                          <td className="px-4 py-3">
                            {isMe ? (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">
                                Assigned to your team ({teamName})
                              </span>
                            ) : partner.teamId ? (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                                {tInfo?.name || 'Another Team'}
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-100">
                                General / Unassigned
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-right">
                            {/* If unassigned, allow team to self-assign! */}
                            {!partner.teamId && (
                              <button
                                id={`claim-partner-${partner.id}`}
                                onClick={() => onAssignPartner(partner.id, activeTeamId)}
                                className="inline-flex items-center gap-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 px-2.5 py-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer"
                              >
                                Assign to my team
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            )}

                            {/* If assigned to another team, show warning */}
                            {partner.teamId && !isMe && (
                              <button
                                id={`transfer-partner-${partner.id}`}
                                onClick={() => {
                                  if (confirm(`Are you sure you want to transfer ${partner.name} from their current team to ${teamName}?`)) {
                                    onAssignPartner(partner.id, activeTeamId);
                                  }
                                }}
                                className="text-[10px] text-slate-400 hover:text-emerald-700 hover:underline transition-colors font-semibold"
                              >
                                Re-assign to my team
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
