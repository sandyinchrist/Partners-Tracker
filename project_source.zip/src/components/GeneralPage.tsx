import React, { useState } from 'react';
import { Partner, Team, GivingData } from '../types';
import {
  Users,
  Search,
  UserPlus,
  Plus,
  ArrowRight,
  HelpCircle,
  CheckCircle,
  ShieldCheck,
  Globe,
  Tag,
  Upload
} from 'lucide-react';
import { parsePartnerNames, formatMonthKey } from '../utils';

interface GeneralPageProps {
  partners: Partner[];
  teams: Team[];
  givingData: GivingData;
  onAddPartners: (newNames: string[], teamId: string | null) => void;
  onAssignPartner: (partnerId: string, teamId: string | null) => void;
  onGoToLogin: () => void;
}

export default function GeneralPage({
  partners,
  teams,
  givingData,
  onAddPartners,
  onAssignPartner,
  onGoToLogin
}: GeneralPageProps) {
  // General partner page states
  const [searchQuery, setSearchQuery] = useState('');
  const [bulkInput, setBulkInput] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [selectedTeamAssign, setSelectedTeamAssign] = useState<{ [partnerId: string]: string }>({});

  // Drag and Drop upload states
  const [isDragging, setIsDragging] = useState(false);
  const [fileError, setFileError] = useState('');
  const [fileSuccess, setFileSuccess] = useState('');

  const handleFileProcess = (file: File) => {
    setFileError('');
    setFileSuccess('');
    
    const fileType = file.name.split('.').pop()?.toLowerCase();
    if (fileType !== 'txt' && fileType !== 'csv') {
      setFileError('Unsupported file type. Please upload a .txt or .csv file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (!text) {
        setFileError('Could not read file content or file is empty.');
        return;
      }

      const lines = text.split(/\r?\n/);
      const parsedNames: string[] = [];

      lines.forEach((line, index) => {
        const trimmed = line.trim();
        if (!trimmed) return;

        if (trimmed.includes(',')) {
          const parts = trimmed.split(',').map(p => p.trim()).filter(p => p.length > 0);
          
          const containsHeaderWord = parts.some(p => {
            const lp = p.toLowerCase();
            return lp === 'name' || lp === 'partner' || lp === 'partner name' || lp === 'email' || lp === 'id' || lp === 'team';
          });
          if (index === 0 && containsHeaderWord) {
            return;
          }

          if (parts.length > 0) {
            const isEmail = (str: string) => str.includes('@');
            const isNumber = (str: string) => !isNaN(Number(str));
            
            if (parts.length === 2 && !isEmail(parts[0]) && !isEmail(parts[1]) && !isNumber(parts[0]) && !isNumber(parts[1])) {
              const namePart = parts.find(p => !isEmail(p) && !isNumber(p));
              if (namePart && namePart.length > 1) {
                parsedNames.push(namePart);
              }
            } else {
              const firstCol = parts[0];
              if (firstCol && !isEmail(firstCol) && !isNumber(firstCol) && firstCol.length > 1) {
                parsedNames.push(firstCol);
              }
            }
          }
        } else {
          if (trimmed.length > 1) {
            parsedNames.push(trimmed);
          }
        }
      });

      const cleanedNames = parsedNames.filter(name => {
        const l = name.toLowerCase();
        return l !== 'name' && l !== 'partner' && l !== 'partner name' && l !== 'full name' && l !== 'first name' && l !== 'last name';
      });

      if (cleanedNames.length === 0) {
        setFileError('No valid partner names found in the file.');
        return;
      }

      setBulkInput(prev => {
        const prefix = prev.trim() ? prev.trim() + '\n' : '';
        return prefix + cleanedNames.join('\n');
      });

      setFileSuccess(`Successfully parsed ${cleanedNames.length} names from "${file.name}"!`);
      setTimeout(() => setFileSuccess(''), 6000);
    };

    reader.onerror = () => {
      setFileError('An error occurred while reading the file.');
    };

    reader.readAsText(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  // 1. Get partners who are in the General (unassigned) list
  const generalPartners = partners.filter(p => p.teamId === null);

  // Filter General list
  const filteredGeneralPartners = generalPartners.filter(partner => {
    return partner.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
           partner.id.toLowerCase().includes(searchQuery.toLowerCase());
  });

  // Global look up: search all partners in the system
  const [globalQuery, setGlobalQuery] = useState('');
  const filteredAllPartners = partners.filter(partner => {
    if (!globalQuery || globalQuery.trim().length < 2) return false;
    return partner.name.toLowerCase().includes(globalQuery.toLowerCase()) ||
           partner.id.toLowerCase().includes(globalQuery.toLowerCase());
  });

  // Handle upload of names
  const handleBulkUploadGeneral = (e: React.FormEvent) => {
    e.preventDefault();
    const names = parsePartnerNames(bulkInput);
    if (names.length === 0) return;

    onAddPartners(names, null); // Add to general/null team
    setBulkInput('');
    setSuccessMessage(`Successfully added ${names.length} partners to the general unassigned list.`);
    setTimeout(() => setSuccessMessage(''), 5000);
  };

  const handleAssignToTeamClick = (partnerId: string) => {
    const chosenTeamId = selectedTeamAssign[partnerId];
    if (!chosenTeamId || chosenTeamId === '') return;

    onAssignPartner(partnerId, chosenTeamId);
    
    // Clear assignment choice state
    setSelectedTeamAssign(prev => {
      const copy = { ...prev };
      delete copy[partnerId];
      return copy;
    });
  };

  return (
    <div id="general-page-root" className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      {/* Dynamic Welcome Jumbotron */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-indigo-950 text-white rounded-3xl p-8 shadow-xl relative overflow-hidden">
        <div className="max-w-2xl space-y-3 z-10 relative">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/25 uppercase tracking-wider">
            <Globe className="w-3.5 h-3.5" />
            General Directory
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-sans tracking-tight">
            Partner Distribution Portal
          </h2>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-1/2 -right-8 w-44 h-44 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Grid of General Partners & Bulk Upload */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: General / Unassigned partners list */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900 font-sans flex items-center gap-1.5">
                  <Tag className="w-4.5 h-4.5 text-amber-500" />
                  Unassigned General Partners
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  These partners need to be assigned to one of the 6 teams.
                </p>
              </div>
              <span className="text-[10px] font-mono font-semibold text-amber-700 bg-amber-50 border border-amber-100 px-2 py-0.5 rounded-full">
                {generalPartners.length} Partners Available
              </span>
            </div>

            {/* Local Search Input */}
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                id="general-partner-search"
                type="text"
                placeholder="Search unassigned partners by name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/15 focus:border-emerald-500 transition-all font-sans"
              />
            </div>

            {/* Partners list table */}
            <div className="border border-slate-150 rounded-xl overflow-hidden">
              {filteredGeneralPartners.length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-1">
                  <HelpCircle className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-xs font-semibold">No unassigned partners found.</p>
                  <p className="text-[10px]">All partners might be assigned, or adjust search filter.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 max-h-[400px] overflow-y-auto">
                  {filteredGeneralPartners.map((partner) => (
                    <div key={partner.id} className="p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-3 hover:bg-slate-50/40 transition-colors">
                      <div>
                        <p className="text-xs font-bold text-slate-800 font-sans">{partner.name}</p>
                        <p className="text-[9px] font-mono text-slate-400">Partner ID: {partner.id}</p>
                      </div>

                      {/* Team Assignment trigger */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <select
                          id={`assign-select-${partner.id}`}
                          value={selectedTeamAssign[partner.id] || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setSelectedTeamAssign(prev => ({ ...prev, [partner.id]: val }));
                          }}
                          className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-[11px] text-slate-800 font-sans focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        >
                          <option value="">Choose Team...</option>
                          {teams.map(t => (
                            <option key={t.id} value={t.id}>{t.name}</option>
                          ))}
                        </select>
                        <button
                          id={`assign-confirm-${partner.id}`}
                          onClick={() => handleAssignToTeamClick(partner.id)}
                          disabled={!selectedTeamAssign[partner.id]}
                          className="bg-slate-900 hover:bg-slate-800 disabled:opacity-40 disabled:pointer-events-none text-white px-2.5 py-1.5 rounded-lg text-[10px] font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1"
                        >
                          Assign
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Upload and Global lookup */}
        <div className="lg:col-span-5 space-y-6">
          {/* Upload to General */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 font-sans flex items-center gap-1.5">
                <UserPlus className="w-4.5 h-4.5 text-emerald-500" />
                Upload General Partners
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Paste names here to register them to the unassigned General category.
              </p>
            </div>

            <form onSubmit={handleBulkUploadGeneral} className="space-y-4">
              {/* File Drag and Drop / Selection Area */}
              <div className="space-y-2">
                <div
                  id="general-file-drop-zone"
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => document.getElementById('general-file-picker')?.click()}
                  className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-1.5 select-none ${
                    isDragging
                      ? 'border-emerald-500 bg-emerald-50/50 scale-[1.01]'
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-300'
                  }`}
                >
                  <input
                    id="general-file-picker"
                    type="file"
                    accept=".txt,.csv"
                    className="hidden"
                    onChange={handleFileInputChange}
                  />
                  <Upload className={`w-6 h-6 ${isDragging ? 'text-emerald-500 animate-bounce' : 'text-slate-400'}`} />
                  <p className="text-[11px] font-semibold text-slate-700">
                    Drag and drop your .txt or .csv list here, or <span className="text-emerald-600 underline font-bold">browse</span>
                  </p>
                  <p className="text-[9px] text-slate-400 font-mono">
                    Extracts names instantly
                  </p>
                </div>

                {/* File feedback messages */}
                {fileError && (
                  <p id="general-file-error" className="text-[10px] text-red-600 font-medium">
                    ⚠️ {fileError}
                  </p>
                )}
                {fileSuccess && (
                  <p id="general-file-success" className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse" />
                    {fileSuccess}
                  </p>
                )}
              </div>

              <textarea
                id="general-bulk-names"
                rows={5}
                required
                placeholder="Example:&#10;Brother Daniel Cooper&#10;Sister Ruth Vance"
                value={bulkInput}
                onChange={(e) => setBulkInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-mono text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all leading-relaxed"
              />

              {successMessage && (
                <div id="general-upload-success" className="p-3 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-100 text-xs font-semibold flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>{successMessage}</span>
                </div>
              )}

              <button
                id="general-bulk-submit"
                type="submit"
                className="w-full bg-slate-950 hover:bg-slate-900 active:scale-95 text-white py-2 px-4 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Plus className="w-4 h-4" />
                Upload Partners List
              </button>
            </form>
          </div>

          {/* Global Look-up Search Area */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 font-sans flex items-center gap-1.5">
                <Search className="w-4.5 h-4.5 text-indigo-500" />
                Search Area: All Partners
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Look up any partner's current team assignment instantly.
              </p>
            </div>

            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                id="general-global-search"
                type="text"
                placeholder="Type 2+ letters of partner's name..."
                value={globalQuery}
                onChange={(e) => setGlobalQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/15 focus:border-emerald-500 transition-all font-sans"
              />
            </div>

            {/* Global look up results */}
            <div className="space-y-2 max-h-[180px] overflow-y-auto">
              {globalQuery.trim().length >= 2 && filteredAllPartners.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">No partners found matching "{globalQuery}".</p>
              ) : (
                filteredAllPartners.map(p => {
                  const assignedTeam = teams.find(t => t.id === p.teamId);
                  return (
                    <div key={p.id} className="p-2.5 bg-slate-50 border border-slate-100 rounded-lg flex justify-between items-center text-xs">
                      <div>
                        <p className="font-bold text-slate-800">{p.name}</p>
                        <p className="text-[9px] text-slate-400 font-mono">ID: {p.id}</p>
                      </div>
                      <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-semibold ${
                        assignedTeam ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-amber-50 text-amber-700 border border-amber-100'
                      }`}>
                        {assignedTeam ? assignedTeam.name : 'Unassigned (General)'}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
